package edu.mum.cs.cs425.lab9solutions.arrayutils.q7.service;

public interface ArrayFlattenerService {

    public int[] flattenArray(int[][] a_in);

}
